WITH user_data AS (
  SELECT
    platform,
    from_hex(address) AS token_address,
    TRY_CAST(timestamp AS DATE) AS day
  FROM dune.brandebille.dataset_potential_price_pumping_high_return_tokens_basic_delisted
  WHERE
    platform = 'bsc'
), 
dex_data AS (
    SELECT 
        ud.day AS day,
        t."tx_from" AS maker,
        t."token_bought_address" AS token_buy,
        t."token_sold_address" AS token_sold,
        t.amount_usd AS amount,
        ud.token_address AS token_address,
        ud.platform AS platform
    FROM dex.trades t
    JOIN user_data ud ON 
        (t.token_bought_address = ud.token_address OR t.token_sold_address = ud.token_address) AND
        DATE_TRUNC('day', t.block_time) = ud.day
    WHERE 
        t.blockchain = 'bnb'
),
daily_volumes AS (
    SELECT
        day,
        platform,
        token_address,
        maker AS address,
        SUM(CASE WHEN token_sold = token_address THEN amount ELSE 0 END) AS sell_volume,
        SUM(CASE WHEN token_buy = token_address THEN amount ELSE 0 END) AS buy_volume,
        SUM(amount) AS total_volume
    FROM dex_data
    GROUP BY 1, 2, 3, 4
),
daily_stats AS (
    SELECT
        day,
        platform,
        token_address,
        COUNT(DISTINCT address) AS unique_addresses,
        SUM(total_volume) AS day_total_volume,
        SUM(buy_volume) AS day_buy_volume
    FROM daily_volumes
    GROUP BY 1, 2, 3
),
concentration_metrics AS (
    SELECT
        dv.day,
        dv.platform,
        dv.token_address,
        dv.address,
        dv.sell_volume,
        dv.buy_volume,
        dv.total_volume,
        dv.total_volume / NULLIF(ds.day_total_volume, 0) AS volume_percentage,
        CASE WHEN dv.sell_volume > 0 AND dv.buy_volume > 0 THEN 1 ELSE 0 END AS is_both_buyer_seller,
        ds.unique_addresses,
        ds.day_buy_volume / NULLIF(ds.day_total_volume, 0) AS buy_volume_percentage
    FROM daily_volumes dv
    JOIN daily_stats ds ON 
        dv.day = ds.day AND
        dv.platform = ds.platform AND
        dv.token_address = ds.token_address
    ORDER BY dv.day, dv.platform, dv.token_address, dv.total_volume DESC
),
filtered_tokens AS (
    SELECT DISTINCT
        day,
        platform,
        token_address
    FROM daily_stats
    WHERE 
        -- Condition: Number of unique makers is less than 11
        unique_addresses <= 10
)
SELECT
    cm.day,
    cm.token_address,
    cm.address AS maker,
    cm.sell_volume,
    cm.buy_volume,
    cm.volume_percentage
FROM concentration_metrics cm
JOIN filtered_tokens ft ON
    cm.day = ft.day AND
    cm.platform = ft.platform AND
    cm.token_address = ft.token_address
ORDER BY cm.day, cm.platform, cm.token_address, cm.volume_percentage DESC