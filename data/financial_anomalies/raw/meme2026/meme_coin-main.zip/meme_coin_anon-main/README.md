# A Midsummer Meme's Dream: Investigating Market Manipulations in the Meme Coin Ecosystem

This repository contains the data and code used for the paper, "A Midsummer Meme's Dream: Investigating Market Manipulations in the Meme Coin Ecosystem."

---

### Abstract

From viral jokes to a billion-dollar phenomenon, meme coins have become one of the most popular segments in cryptocurrency markets. Unlike utility-focused crypto assets like Bitcoin or Ethereum, meme coins derive value primarily from community sentiment, making them vulnerable to manipulation. This study presents a cross-chain analysis of the meme coin ecosystem, examining 34,988 tokens across Ethereum, BNB Smart Chain, Solana, and Base. We characterize their tokenomics and track their growth in a three-month longitudinal analysis.

The research finds that among high-return tokens (>100%), an alarming 82.8% show evidence of artificial growth strategies designed to create a misleading appearance of market interest. These strategies include wash trading and a new form of manipulation defined as Liquidity Pool-Based Price Inflation (LPI). The study analyzes how different manipulations are combined and executed sequentially, finding that profit extraction schemes, such as pump and dumps and rug pulls, typically follow initial manipulations like wash trading or LPI, indicating how early manipulations create the foundation for later exploitation. These findings reveal that combined manipulations are widespread among high-performing meme coins, suggesting their dramatic gains are often driven by coordinated efforts rather than natural market dynamics.

---

### Repository Contents

This repository contains the data and code used for the paper, "A Midsummer Meme's Dream: Investigating Market Manipulations in the Meme Coin Ecosystem."

The repository is organized as follows:

  * `data/`: Contains all the datasets used in the study.
  * `dune_queries/`: Contains all the SQL queries used to collect data from Dune Analytics.
  * `python notebooks`: Jupyter notebooks for data analysis and manipulation detection.

---

### Dependencies

All required Python libraries are listed in `requirements.txt`. You can install them by running:

```
pip install -r requirements.txt
```

---

### Data Directory (`data/`)

The `data` directory contains the following key files and subdirectories:

**Overall Dataset:**

  * `confirmed_meme_coins.csv`: The final dataset of 34,988 tokens confirmed as meme coins after the dataset refinement, including the symbol, platform, name, and address for each token.
  * `creation_date_tokens.csv`: Data on 31,811 tokens from Ethereum, BSC, Solana, and Base, including the symbol, name, platform, address, and smart contract creation date.
  * `price_changes_mid_january_snapshot.csv`: Data on price changes during the three months study window (mid October - mid January) to peform the price performance evaluation study. It includes: name, platform, address, price_old (mid October), and price_new (mid January).

**Study on High-Performing Meme Coins:**

  * `high_performing_meme_coins.csv`: The 707 meme coins with a price return of over 100% during the three-month study window, including their name, platform, price, market cap, volume, and address at different time points.
  * `security_metrics_info_high_performing_tokens.csv`: Security metrics for high-performing meme coins collected from Gecko Terminal and DexScreener.
  * `HP_tokens_with_anomalies.csv`: High-performing tokens that show anomalies in ownership concentration or are identified as honeypots.
  * `ohlcv_data_day_until_mid_january.zip`: Zipped directory containing daily OHLCV (Open, High, Low, Close, Volume) data for each HP token until mid-January, used for detecting wash trading and LPI.
  * `ohlcv_data_day_until_mid_march.zip`: Zipped directory with daily OHLCV data for each HP token until mid-March, used for detecting rug pulls.
  * `ohlcv_data_hour_until_mid_march.zip`: Zipped directory with hourly OHLCV data for each HP token until mid-March, used for detecting pump and dumps.
  * `potential_wash_trading_activities.csv`: Detected potential wash trading activities.
  * `potential_LPI_activities.csv`: Detected potential LPI activities.
  * `dune_data_on_potential_wash_trading_makers_HP_coins.csv`: Data from Dune Analytics to confirm wash trading detection on high-performing tokens.
  * `dune_data_on_potential_lpi_makers_HP_coins.csv`: Data from Dune to confirm LPI activities on high-performing tokens.
  * `wash_trading_detected.csv`: Confirmed wash trading detected using Dune data.
  * `lpi_operations_detected.csv`: Confirmed LPI activities detected using Dune data.
  * `rug_pulls_detected_on_performing_tokens_after_mid_january.csv`: Rug pulls detected on high-performing tokens after mid-January.
  * `pump_and_dumps_on_performing_tokens_after_mid_january.csv`: Pump and dumps detected on high-performing meme coins after mid-January.

**Study on Delisted Tokens:**

  * `delisted_tokens_popular_aggregators.csv`: The 124 tokens delisted from Coingecko and Coinmarketcap, including their name, platform, and address.
  * `dune_data_on_lpi_delisted_tokens.csv`: Data from Dune to confirm LPI activities on delisted tokens.
  * `dune_data_on_wash_trading_delisted_tokens.csv`: Data from Dune to confirm wash trading on delisted tokens.
  * `delisted_tokens_with_artificial_growth.csv`: The 84 delisted tokens involved in artificial growth.
  * `delisted_tokens_profit_extraction.csv`: The 30 delisted tokens involved in profit extraction schemes.

---

### Dune Queries Directory (`dune_queries/`)

This directory contains all the SQL queries used to collect data from Dune Analytics. The `lpi_detection/` and `wash_trading/` subdirectories contain SQL queries for each blockchain to confirm LPI and wash trading activities, respectively.

---

### Code (`.ipynb` notebooks)

The code is written in Python and organized in a series of Jupyter notebooks.

  * `anomaly_detection_high_performing_memes.ipynb`: Detects anomalies in high-performing tokens using security information from `security_metrics_info_high_performing_tokens.csv`.
  * `wash_trading_detection.ipynb`: Detects wash trading activities on high-performing tokens.
  * `LPI_detection.ipynb`: Detects LPI operations on high-performing tokens.
  * `anomalies_and_growth_strategies_analysis.ipynb`: Analyzes the combination of anomalies and artificial growth on high-performing meme coins.
  * `rug_pull_detection.ipynb`: Detects rug pulls involving high-performing meme coins.
  * `pump_and_dumps_detection.ipynb`: Detects pump and dumps in high-performing meme coins.


**Note:** The notebooks for wash trading, LPI, rug pull, and pump and dump detection can also be used to analyze the delisted tokens by changing the input data path to point to the delisted tokens' data files.

