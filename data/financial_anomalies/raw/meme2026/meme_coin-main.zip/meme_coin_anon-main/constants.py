
CONFIRMED_MEMES = 'data/confirmed_meme_coins.csv'
HIGH_PERFORMING_MEMES = 'data/high_performing_meme_coins.csv'
CREATION_DATE_MEMES = 'data/creation_date_tokens.csv'

# Anomaly detection study
SECURITY_INFO_HP_MEMES = 'data/security_metrics_info_high_performing_tokens.csv'
HP_TOKENS_WITH_ANOMALIES = 'data/HP_tokens_with_anomalies.csv'

# Addinational Dune data for wash trading and LPI operations
DUNE_DATA_WASH_TRADING = 'data/dune_data_on_potential_wash_trading_makers_HP_coins.csv'
DUNE_DATA_LPI = 'data/dune_data_on_potential_lpi_makers_HP_coins.csv'

# Manipulations detected 
WASH_TRADING_DETECTED_HP = 'data/wash_trading_detected.csv'
LPI_DETECTED_HP = 'data/lpi_operations_detected.csv'
RUG_PULLS_DETECTED = 'data/rug_pulls_detected_on_performing_tokens_after_mid_march.csv'
PUMP_AND_DUMPS_DETECTED = 'data/pump_and_dumps_on_performing_tokens_after_mid_march.csv'

# Delisted tokens
DELISTED_TOKENS = 'data/delisted_tokens_popular_aggregators.csv'
DELISTED_TOKENS_WITH_ARTIFICIAL_GROWTH = 'data/delisted_tokens_with_artificial_growth.csv'
DELISTED_TOKENS_WITH_PROFIT_EXTRACTION = 'data/delisted_tokens_profit_extraction.csv'
DUNE_DATA_WASH_TRADING_DELISTED = 'data/dune_data_on_wash_trading_delisted_tokens.csv'
DUNE_DATA_LPI_DELISTED = 'data/dune_data_on_lpi_delisted_tokens.csv'