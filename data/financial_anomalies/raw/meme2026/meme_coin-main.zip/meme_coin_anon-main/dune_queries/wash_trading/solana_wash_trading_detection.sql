WITH user_data AS (
  SELECT
    platform,
    address_low AS token_address,
    TRY_CAST(timestamp AS DATE) AS day
  FROM (
    SELECT
      platform,
      address_low,
      timestamp
    FROM dune.brandebille.dataset_delisted_tokens_potential_wash_trading
    WHERE
      platform = 'solana'
  ) base_data
),

dex_data AS (
    SELECT
        ud.day AS day,
        t."trader_id" AS maker,
        t."token_bought_mint_address" AS token_buy,
        t."token_sold_mint_address" AS token_sold,
        t.amount_usd AS amount,
        ud.token_address AS token_address,
        ud.platform AS platform
    FROM dex_solana.trades t
    JOIN user_data ud ON
        DATE_TRUNC('day', t.block_time) = ud.day AND
        (t.token_bought_mint_address = ud.token_address OR t.token_sold_mint_address = ud.token_address)
    WHERE
        t.blockchain = 'solana'
),
daily_volumes_by_maker AS (
    SELECT
        day,
        platform,
        token_address,
        maker AS address,
        SUM(CASE WHEN token_sold = token_address THEN amount ELSE 0 END) AS sell_volume,
        SUM(CASE WHEN token_buy = token_address THEN amount ELSE 0 END) AS buy_volume,
        SUM(amount) AS total_volume
    FROM dex_data
    GROUP BY 1, 2, 3, 4
),
daily_token_stats AS (
    SELECT
        day,
        platform,
        token_address,
        COUNT(DISTINCT address) AS unique_addresses,
        SUM(buy_volume) AS day_buy_volume,
        SUM(total_volume) AS day_total_volume
    FROM daily_volumes_by_maker
    GROUP BY 1, 2, 3
),
filtered_tokens AS (
    SELECT
        day,
        platform,
        token_address
    FROM daily_token_stats
    WHERE 
        unique_addresses <= 50
)
-- Final query just gets the relevant maker data for the filtered tokens
SELECT
    dv.day,
    dv.token_address,
    dv.address AS maker,
    dv.sell_volume,
    dv.buy_volume,
    dv.total_volume / NULLIF(dt.day_total_volume, 0) AS volume_percentage
FROM daily_volumes_by_maker dv
JOIN filtered_tokens ft ON
    dv.day = ft.day AND
    dv.platform = ft.platform AND
    dv.token_address = ft.token_address
JOIN daily_token_stats dt ON
    dv.day = dt.day AND
    dv.platform = dt.platform AND
    dv.token_address = dt.token_address
ORDER BY dv.day, dv.platform, dv.token_address, volume_percentage DESC